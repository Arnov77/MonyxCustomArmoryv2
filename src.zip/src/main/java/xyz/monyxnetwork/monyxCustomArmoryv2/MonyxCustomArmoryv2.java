package xyz.monyxnetwork.monyxCustomArmoryv2;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import xyz.monyxnetwork.monyxCustomArmoryv2.commands.ArmorCommand;
import xyz.monyxnetwork.monyxCustomArmoryv2.listeners.ArmorSetListener;

public class MonyxCustomArmoryv2 extends JavaPlugin {

    @Override
    public void onEnable() {
        // Mendaftarkan event listener
        getServer().getPluginManager().registerEvents(new ArmorSetListener(), this);

        // Mendaftarkan command
        getCommand("monyxcustomarmory").setExecutor(new ArmorCommand());

        Bukkit.getLogger().info("MonyxCustomArmoryv2 Enabled!");
    }

    @Override
    public void onDisable() {
        Bukkit.getLogger().info("MonyxCustomArmoryv2 Disabled!");
    }
}
