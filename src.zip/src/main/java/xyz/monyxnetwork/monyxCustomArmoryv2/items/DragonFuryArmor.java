package xyz.monyxnetwork.monyxCustomArmoryv2.items;

import de.tr7zw.nbtapi.NBTItem;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class DragonFuryArmor {

    public static ItemStack getDragonFuryHelmet() {
        ItemStack helmet = new ItemStack(Material.DIAMOND_HELMET);
        NBTItem nbtHelmet = new NBTItem(helmet);
        nbtHelmet.setString("CustomID", "DragonFuryArmor");
        return nbtHelmet.getItem();
    }

    public static ItemStack getDragonFuryChestplate() {
        ItemStack chestplate = new ItemStack(Material.DIAMOND_CHESTPLATE);
        NBTItem nbtChestplate = new NBTItem(chestplate);
        nbtChestplate.setString("CustomID", "DragonFuryArmor");
        return nbtChestplate.getItem();
    }

    public static ItemStack getDragonFuryLeggings() {
        ItemStack leggings = new ItemStack(Material.DIAMOND_LEGGINGS);
        NBTItem nbtLeggings = new NBTItem(leggings);
        nbtLeggings.setString("CustomID", "DragonFuryArmor");
        return nbtLeggings.getItem();
    }

    public static ItemStack getDragonFuryBoots() {
        ItemStack boots = new ItemStack(Material.DIAMOND_BOOTS);
        NBTItem nbtBoots = new NBTItem(boots);
        nbtBoots.setString("CustomID", "DragonFuryArmor");
        return nbtBoots.getItem();
    }
}
