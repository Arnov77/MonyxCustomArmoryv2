package xyz.monyxnetwork.monyxCustomArmoryv2.listeners;

import de.tr7zw.nbtapi.NBTItem;
import org.bukkit.Material;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class ArmorSetListener implements Listener {

    // Cek apakah pemain memakai Dragon Fury Armor Set
    private boolean isWearingFullDragonFurySet(Player player) {
        ItemStack[] armor = player.getInventory().getArmorContents();
        for (ItemStack item : armor) {
            if (item == null || item.getType() == Material.AIR) return false;
            NBTItem nbtItem = new NBTItem(item);
            if (!"DragonFuryArmor".equals(nbtItem.getString("CustomID"))) {
                return false;
            }
        }
        return true;
    }

    // Event untuk mendeteksi ketika pemain bergerak (untuk efek Strength di dekat api/lava)
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();

        // Cek apakah pemain memakai set armor penuh
        if (isWearingFullDragonFurySet(player)) {
            // Berikan efek Fire Resistance dan Slowness saat memakai full set
            player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 100, 1, true, false));
            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 100, 1, true, false));

            // Cek apakah pemain berada dalam radius 5 blok dari api atau lava
            if (isNearFireOrLava(player)) {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 1, true, false));
            }
        }
    }

    // Event untuk mendeteksi ketika pemain jongkok (untuk membakar hostile mobs)
    @EventHandler
    public void onPlayerToggleSneak(PlayerToggleSneakEvent event) {
        Player player = event.getPlayer();
        if (!event.isSneaking()) return;

        // Cek apakah pemain memakai set armor penuh
        if (isWearingFullDragonFurySet(player)) {
            player.getNearbyEntities(5, 5, 5).stream()
                    .filter(entity -> entity instanceof Monster)
                    .forEach(entity -> entity.setFireTicks(100)); // Membakar mob selama 5 detik
        }
    }

    // Metode untuk mengecek apakah pemain berada di dekat api atau lava dalam radius 5 blok
    private boolean isNearFireOrLava(Player player) {
        int radius = 5;

        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Material blockType = player.getLocation().add(x, y, z).getBlock().getType();
                    if (blockType == Material.FIRE || blockType == Material.LAVA) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
