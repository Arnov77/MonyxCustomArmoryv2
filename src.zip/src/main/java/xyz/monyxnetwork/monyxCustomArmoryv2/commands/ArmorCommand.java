package xyz.monyxnetwork.monyxCustomArmoryv2.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import xyz.monyxnetwork.monyxCustomArmoryv2.items.DragonFuryArmor;

public class ArmorCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2 || !args[0].equalsIgnoreCase("give") || !args[1].equalsIgnoreCase("armor")) {
            sender.sendMessage("Usage: /monyxcustomarmory give armor <armor_name> [player_name]");
            return true;
        }

        Player target = null;
        if (args.length == 3) {
            target = Bukkit.getPlayer(args[2]);
            if (target == null) {
                sender.sendMessage("Player not found.");
                return true;
            }
        } else if (sender instanceof Player) {
            target = (Player) sender;
        }

        if (target == null) {
            sender.sendMessage("You must specify a player.");
            return true;
        }

        String armorName = args[1];

        // Check if the armor name is valid (for now only "DragonFuryArmor" is supported)
        if (armorName.equalsIgnoreCase("DragonFuryArmor")) {
            target.getInventory().setHelmet(DragonFuryArmor.getDragonFuryHelmet());
            target.getInventory().setChestplate(DragonFuryArmor.getDragonFuryChestplate());
            target.getInventory().setLeggings(DragonFuryArmor.getDragonFuryLeggings());
            target.getInventory().setBoots(DragonFuryArmor.getDragonFuryBoots());
            sender.sendMessage("Given " + armorName + " to " + target.getName());
        } else {
            sender.sendMessage("Unknown armor: " + armorName);
        }

        return true;
    }
}
